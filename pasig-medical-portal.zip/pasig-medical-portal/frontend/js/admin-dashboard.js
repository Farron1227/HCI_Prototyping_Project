document.addEventListener("DOMContentLoaded", () => {
  // Load Appointments
  fetch("http://localhost:3000/api/appointments")
    .then(res => res.json())
    .then(data => {
      const table = document.getElementById("appointments-table");
      table.innerHTML = "";
      if (data.length === 0) {
        table.innerHTML = "<tr><td colspan='4'>No appointments found.</td></tr>";
      } else {
        data.forEach(appt => {
          const row = `
            <tr>
              <td>${appt.name}</td>
              <td>${appt.contact}</td>
              <td>${appt.facility}</td>
              <td>${appt.date}</td>
            </tr>`;
          table.innerHTML += row;
        });
      }
    })
    .catch(err => {
      document.getElementById("appointments-table").innerHTML = "<tr><td colspan='4'>Error loading data</td></tr>";
      console.error(err);
    });

  // Load Lab Results
  Promise.all([
    fetch("http://localhost:3000/api/labs").then(res => res.json()),
    fetch("http://localhost:3000/api/users").then(res => res.json())
  ])
  .then(([labs, users]) => {
    const userMap = users.reduce((map, user) => {
      map[user.id] = user.name;
      return map;
    }, {});

    const labDiv = document.getElementById("lab-results");
    if (labs.length === 0) {
      labDiv.innerHTML = "<p>No lab results available.</p>";
    } else {
      const table = `
        <table class="table table-striped">
          <thead>
            <tr>
              <th>User</th>
              <th>Lab No.</th>
              <th>Date</th>
              <th>File</th>
            </tr>
          </thead>
          <tbody>
            ${labs.map(l => `
              <tr>
                <td>${userMap[l.userId] || 'Unknown User'}</td>
                <td>${l.labNo}</td>
                <td>${l.date}</td>
                <td><a href="uploads/${l.file}" target="_blank">${l.file}</a></td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      `;
      labDiv.innerHTML = table;
    }
  })
  .catch(err => {
    document.getElementById("lab-results").innerHTML = "<p class='text-danger'>Error loading lab results.</p>";
    console.error(err);
  });

  // Load Vaccine Records
  fetch("http://localhost:3000/api/vax")
    .then(res => res.json())
    .then(vaccines => {
      fetch("http://localhost:3000/api/users")
        .then(res => res.json())
        .then(users => {
          const userMap = users.reduce((map, user) => {
            map[user.id] = user.name;
            return map;
          }, {});

          const vacDiv = document.getElementById("vaccine-records");
          if (vaccines.length === 0) {
            vacDiv.innerHTML = "<p>No vaccine records available.</p>";
          } else {
            const table = `
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th>User</th>
                    <th>Dose</th>
                    <th>Date</th>
                  </tr>
                </thead>
                <tbody>
                  ${vaccines.map(v => `
                    <tr>
                      <td>${userMap[v.id] || 'Unknown User'}</td>
                      <td>${v.dose}</td>
                      <td>${v.date}</td>
                    </tr>
                  `).join("")}
                </tbody>
              </table>
            `;
            vacDiv.innerHTML = table;
          }
        });
    })
    .catch(err => {
      document.getElementById("vaccine-records").innerHTML = "<p class='text-danger'>Error loading vaccine data.</p>";
      console.error(err);
    });

  // Load Users
  fetch("http://localhost:3000/api/users")
    .then(res => res.json())
    .then(users => {
      const table = document.getElementById("user-table");
      table.innerHTML = "";
      if (users.length === 0) {
        table.innerHTML = "<tr><td colspan='4'>No users found.</td></tr>";
      } else {
        users.forEach(user => {
          const row = document.createElement("tr");
          row.innerHTML = `
            <td>${user.name}</td>
            <td>${user.email}</td>
            <td>${user.role || "user"}</td>
            <td><button class="btn btn-sm btn-danger" onclick="deleteUser(${user.id})">Delete</button></td>
          `;
          table.appendChild(row);
        });
      }
    })
    .catch(() => {
      document.getElementById("user-table").innerHTML = "<tr><td colspan='4'>Error loading users.</td></tr>";
    });
});

// Delete User Function
function deleteUser(id) {
  if (confirm("Are you sure you want to delete this user?")) {
    fetch(`http://localhost:3000/api/users/${id}`, {
      method: "DELETE"
    })
    .then(res => {
      if (res.ok) {
        alert("User deleted.");
        location.reload();
      } else {
        alert("Failed to delete user.");
      }
    })
    .catch(() => alert("Server error while deleting user."));
  }
}
