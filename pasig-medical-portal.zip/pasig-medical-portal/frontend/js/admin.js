document.getElementById("login-form").addEventListener("submit", async function (e) {
  e.preventDefault();

  const formData = new FormData(this);
  const email = formData.get("email");
  const password = formData.get("password");

  const res = await fetch("http://localhost:3000/api/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
  });

  const result = await res.json();
  console.log("Login result:", result); // ✅ debug role

  if (result.success) {
    if (result.role === "admin") {
      window.location.href = "admin.html"; // 👈 redirect to admin
    } else {
      window.location.href = "dashboard.html"; // 👈 redirect to user
    }
  } else {
    alert("Login failed: " + result.message);
  }
});
