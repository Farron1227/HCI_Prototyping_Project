// ========== LOGIN ==========
if (document.getElementById('login-form')) {
  document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const form = e.target;
    const data = {
      email: form.email.value,
      password: form.password.value
    };

    try {
      const res = await fetch('http://localhost:3000/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });

      const result = await res.json();

      if (res.ok && result.success) {
        // Save user info
        localStorage.setItem('user', JSON.stringify(result.user));

        // Redirect based on role
        if (result.user.role === 'admin') {
          window.location.href = 'admin.html';
        } else {
          window.location.href = 'dashboard.html';
        }
      } else {
        alert(result.message || 'Login failed.');
      }
    } catch (err) {
      alert('Login server error.');
      console.error(err);
    }
  });

}

// ========== SIGNUP ========== 
if (document.getElementById('signup-form')) {
  document.getElementById('signup-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const form = e.target;
    const data = {
      name: form.name.value,
      email: form.email.value,
      password: form.password.value
    };

    try {
      const res = await fetch('http://localhost:3000/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });

      const result = await res.json();

      if (res.ok) {
        alert('Signup successful! Please login.');
        window.location.href = 'login.html';
      } else {
        alert(result.message || 'Signup failed.');
      }
    } catch (err) {
      alert('Signup server error.');
      console.error(err);
    }
  });
}

// ========== APPOINTMENT SUBMISSION ==========
if (document.getElementById('appointment-form')) {
  document.getElementById('appointment-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const form = e.target;
    const data = {
      name: form.name.value,
      contact: form.contact.value,
      date: form.date.value,
      service: form.service.value
    };

    try {
      const res = await fetch('http://localhost:3000/api/appointments/reserve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });

      const result = await res.json();

      if (res.ok) {
        alert('Appointment reserved successfully!');
        form.reset();
      } else {
        alert(result.message || 'Failed to reserve appointment.');
      }
    } catch (err) {
      alert('Error connecting to server.');
      console.error(err);
    }
  });
}

// ========== LAB RESULTS ==========
const user = JSON.parse(localStorage.getItem('user'));

if (document.getElementById('lab-table')) {
  if (!user || !user.id) {
    document.getElementById('lab-table').innerHTML = '<tr><td colspan="3">You must be logged in to view lab results.</td></tr>';
  } else {
    fetch(`http://localhost:3000/api/labs/${user.id}`)
      .then(res => res.json())
      .then(data => {
        const table = document.getElementById('lab-table');
        table.innerHTML = '';
        if (data.length === 0) {
          table.innerHTML = '<tr><td colspan="3">No lab results available.</td></tr>';
        } else {
          data.forEach(lab => {
            const row = document.createElement('tr');
            row.innerHTML = `
              <td>${lab.labNo}</td>
              <td>${lab.date}</td>
              <td><a href="uploads/${lab.file}" target="_blank">${lab.file}</a></td>
            `;
            table.appendChild(row);
          });
        }
      })
      .catch(() => {
        document.getElementById('lab-table').innerHTML = '<tr><td colspan="3" class="text-danger">Error loading lab results.</td></tr>';
      });
  }
}
//Vaccination Status
if (document.getElementById('vax-list')) {
  if (!user || !user.id) {
    document.getElementById('vax-list').innerHTML = '<li class="list-group-item text-danger">You must be logged in to view vaccination status.</li>';
  } else {
    fetch(`http://localhost:3000/api/vax/${user.id}`)
      .then(res => res.json())
      .then(data => {
        const list = document.getElementById('vax-list');
        list.innerHTML = '';

        if (data.length === 0) {
          list.innerHTML = '<li class="list-group-item">No vaccination records found.</li>';
        } else {
          data.forEach(vax => {
            const item = document.createElement('li');
            item.classList.add('list-group-item');
            item.innerHTML = `
              <strong>${vax.dose}</strong> - ${vax.date}
            `;
            list.appendChild(item);
          });
        }
      })
      .catch(err => {
        console.error('Error fetching vaccine data:', err);
        document.getElementById('vax-list').innerHTML = '<li class="list-group-item text-danger">Failed to load vaccination data. See console for details.</li>';
      });
  }
}