const express = require('express');
const router = express.Router();
const {
  getAllLabs,
  getLabsByUser,
  addLabResult
} = require('../controllers/labs');

// Admin: Get all lab results
router.get('/', getAllLabs);

// User: Get lab results by user ID
router.get('/:userId', getLabsByUser);

// Admin: Add new lab result
router.post('/add', addLabResult);

module.exports = router;