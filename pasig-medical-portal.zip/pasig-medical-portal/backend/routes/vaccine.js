const express = require('express');
const router = express.Router();
const { getVaccineStatus, getVaccineStatusByUser } = require('../controllers/vaccine');

// Get all vaccine records (for admin)
router.get('/', getVaccineStatus);

// Get vaccine records by user ID
router.get('/:userId', getVaccineStatusByUser);

module.exports = router;
