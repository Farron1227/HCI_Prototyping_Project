const express = require('express');
const router = express.Router();
const { loginUser, registerUser } = require('../controllers/auth');

router.post('/login', loginUser);
router.post('/signup', registerUser); // ✅ This must point to the updated registerUser

module.exports = router;
