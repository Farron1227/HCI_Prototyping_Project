const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const userFile = path.join(__dirname, '../users.json');

// GET all users
router.get('/', (req, res) => {
  const users = JSON.parse(fs.readFileSync(userFile));
  res.json(users);
});

// DELETE user by ID
router.delete('/:id', (req, res) => {
  const userId = parseInt(req.params.id);
  let users = JSON.parse(fs.readFileSync(userFile));
  users = users.filter(u => u.id !== userId);
  fs.writeFileSync(userFile, JSON.stringify(users, null, 2));
  res.json({ message: "User deleted." });
});

module.exports = router;
