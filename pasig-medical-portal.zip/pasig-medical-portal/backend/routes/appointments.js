const express = require('express');
const router = express.Router();
const { reserveAppointment, getAppointments } = require('../controllers/appointments');

router.post('/reserve', reserveAppointment);
router.get('/', getAppointments);

module.exports = router;
