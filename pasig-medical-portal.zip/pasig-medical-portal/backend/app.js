const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

// ROUTES (place after app initialization)
const authRoutes = require('./routes/auth');
const appointmentRoutes = require('./routes/appointments');
const labRoutes = require('./routes/labs');
const vaccineRoutes = require('./routes/vaccine');
const userRoutes = require('./routes/users'); // 🟢 Move this down if needed

// INITIALIZE EXPRESS
const app = express();

app.use(cors());
app.use(bodyParser.json());

// ROUTES
app.use('/api/auth', authRoutes);
app.use('/api/appointments', appointmentRoutes);
app.use('/api/labs', labRoutes);
app.use('/api/vax', vaccineRoutes);
app.use('/api/users', userRoutes); // ✅ Place after `app` is declared

// START SERVER
const PORT = 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
