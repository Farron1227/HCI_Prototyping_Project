const fs = require('fs');
const path = require('path');
const file = path.join(__dirname, '../vaccine_status.json');

const getVaccineStatus = (req, res) => {
  const vax = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file)) : [];
  res.json(vax);
};

const getVaccineStatusByUser = (req, res) => {
  const { userId } = req.params;
  if (!userId) return res.status(400).json({ message: 'Missing user ID' });

  const vaxData = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file)) : [];
  const userVax = vaxData.filter(v => String(v.id) === userId);
  res.json(userVax);
};

module.exports = { getVaccineStatus, getVaccineStatusByUser };
