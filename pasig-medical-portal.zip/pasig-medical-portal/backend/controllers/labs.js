const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '../lab_results.json');

// Get all lab results (admin)
const getAllLabs = (req, res) => {
  const data = fs.existsSync(filePath) ? JSON.parse(fs.readFileSync(filePath)) : [];
  res.json(data);
};

// Get lab results by user ID (for dashboard)
const getLabsByUser = (req, res) => {
  const { userId } = req.params;
  if (!userId) return res.status(400).json({ message: 'Missing user ID' });

  const data = fs.existsSync(filePath) ? JSON.parse(fs.readFileSync(filePath)) : [];
  const userLabs = data.filter(l => String(l.userId) === userId);
  res.json(userLabs);
};

// Add lab result (admin uploads)
const addLabResult = (req, res) => {
  const { userId, labNo, date, file } = req.body;
  if (!userId || !labNo || !date || !file) {
    return res.status(400).json({ message: 'Missing fields' });
  }

  const newEntry = {
    id: Date.now(),
    userId,
    labNo,
    date,
    file
  };

  let data = fs.existsSync(filePath) ? JSON.parse(fs.readFileSync(filePath)) : [];
  data.push(newEntry);
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
  res.status(201).json({ message: 'Lab result added', lab: newEntry });
};

module.exports = { getAllLabs, getLabsByUser, addLabResult };
