const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '../appointments.json');

const reserveAppointment = (req, res) => {
  const { name, contact, date, service } = req.body;
  const newAppt = { id: Date.now(), name, contact, date, service };

  let data = [];
  if (fs.existsSync(filePath)) {
    data = JSON.parse(fs.readFileSync(filePath));
  }
  data.push(newAppt);
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));

  res.status(201).json({ message: 'Appointment reserved', data: newAppt });
};

const getAppointments = (req, res) => {
  const data = fs.existsSync(filePath) ? JSON.parse(fs.readFileSync(filePath)) : [];
  res.json(data);
};

module.exports = { reserveAppointment, getAppointments };
