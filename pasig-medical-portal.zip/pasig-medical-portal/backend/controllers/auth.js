const fs = require('fs');
const path = require('path');

const userFile = path.join(__dirname, '../users.json');

// ✅ LOGIN CONTROLLER
const loginUser = (req, res) => {
  const { email, password } = req.body;
  const users = JSON.parse(fs.readFileSync(userFile));
  const user = users.find(u => u.email === email && u.password === password);

  if (user) {
    // Send back user data without the password
    const { password, ...userWithoutPassword } = user;
    res.json({ success: true, user: userWithoutPassword });
  } else {
    res.status(401).json({ success: false, message: 'Invalid credentials' });
  }
};

// ✅ SIGNUP CONTROLLER (with default "user" role)
const registerUser = (req, res) => {
  const { name, email, password } = req.body;
  let users = [];

  // Load existing users
  if (fs.existsSync(userFile)) {
    users = JSON.parse(fs.readFileSync(userFile));
  }

  // Prevent duplicate emails
  if (users.find(u => u.email === email)) {
    return res.status(400).json({ message: 'Email already exists' });
  }

  // Create new user with default role
  const newUser = {
    id: Date.now(),
    name,
    email,
    password,
    role: "user"  // ✅ assign role here
  };

  users.push(newUser);
  fs.writeFileSync(userFile, JSON.stringify(users, null, 2));
  res.status(201).json({ message: 'User registered', user: newUser });
};

module.exports = { loginUser, registerUser };
